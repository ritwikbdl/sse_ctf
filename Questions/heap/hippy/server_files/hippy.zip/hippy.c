// gcc -fno-stack-protector -z execstack -g -o stars AsciiFullof*.c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
# define LEN 90

char global[] = "Hiiii";

void ignore_me_init_buffering() {
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stdin, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);
}

void kill_on_timeout(int sig) {
  if (sig == SIGALRM) {
  	printf("[!] Anti DoS Signal. Patch me out for testing.");
    exit(0);
  }
}

void ignore_me_init_signal() {
	signal(SIGALRM, kill_on_timeout);
	alarm(60*3);
}


void start(void)
{
    char *p [12]; 
    int idx = 0;
    while(1){
        char choice;
        printf("\nchoice: ");
        scanf(" %c", &choice);

        switch(choice){
            case 'a':
                {
                    int n ;
                    printf("Pos: ");
                    scanf("%d", &n);
                    p[n] = (char *)malloc(20);
                    // write to p[n]
                    fflush(stdin);
                    printf("data: ");
                    read(0, p[n], 20);
                    break;
                }
            case 'b':{
                int n ;
                printf("Pos: ");
                scanf("%d", &n);
                free(p[n]);
                break;
            }

        }
    }
    return;       
}

void banner(){
    printf("   _____ _____ ______    _____ _______ ______  \n  / ____/ ____|  ____|  / ____|__   __|  ____| \n | (___| (___ | |__    | |       | |  | |__    \n  \\___ \\\\___ \\|  __|   | |       | |  |  __|   \n  ____) |___) | |____  | |____   | |  | |      \n |_____/_____/|______|  \\_____|  |_|  |_|      \n                                               \n                                               \n");
}

int main(){
	ignore_me_init_buffering();
	ignore_me_init_signal();
    printf("system: %p\n", system);
    banner();
    start();
	return 0;
}
